class race {

    constructor(circuito){
        this.circuito = circuito;

    }

    start(){

        
    }
}