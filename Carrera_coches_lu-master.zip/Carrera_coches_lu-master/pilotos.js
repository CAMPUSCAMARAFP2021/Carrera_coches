class pilotos {

    constructor (nombre, vehiculo){
        this.nombre = nombre;
        this.vehiculo = vehiculo;

    }
    elegircoche(){

    }

    repostar(){

    }

    
}