class pilotos extends cars{

    constructor (nombre, vehiculo){
        this.nombre = nombre;
        this.vehiculo = vehiculo;

    }
    elegircoche(){

    }

    repostar(){

    }

    
}