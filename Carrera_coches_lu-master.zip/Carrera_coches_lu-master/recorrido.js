class circuito{
constructor (name, serie = []){
    this.name = name;
    this.serie = serie;
}

}
circuito1 = new circuito("pepe", ["recta", "recta", "curva", "recta", "meta" ]);
console.log(circuito1.serie)
