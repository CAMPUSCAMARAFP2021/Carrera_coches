class Vehiculo {

    speed = 0;
    constructor(speed, speed_max, aceleration, braking) {
        this.speed = speed;
        this.speed_max = speed_max;
        this.aceleration = aceleration;
        this.braking = braking
    }

    Acelerar (){
        this.speed == this.speed_max ? this.speed = this.speed_max : this.speed =+ 10;
    }
   
    Frenar(){
        this.speed = speed - 10;
    }
    
};