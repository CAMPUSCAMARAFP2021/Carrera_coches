class jugadores extends Coche {

    constructor(nick)
    super ()

}