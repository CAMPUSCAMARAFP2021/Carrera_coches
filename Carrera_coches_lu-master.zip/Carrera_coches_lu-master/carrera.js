class circuito {

    vueltas = 0;
    constructor(nombre, kilometros, vueltas, curves, rectas) {
        this.nombre = nombre;
        this.kilometros = kilometros;
        this.vueltas = vueltas;
        this.curves = curves;
        this.rectas = rectas;
    }

    finish() {

    }
}